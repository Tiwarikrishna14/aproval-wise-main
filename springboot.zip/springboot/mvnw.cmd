@echo off
mvn %*
